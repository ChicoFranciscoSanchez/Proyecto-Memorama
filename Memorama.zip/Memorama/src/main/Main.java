package main;

/**
 * Toda la funcionalidad del programa
 * @author 220205792 Sanchez Alvarez Francisco Alberto / Chico
 * @author 222217053 Enriquez Grijalva Manuel
 * @author 221202077 Córdova Salcido Miguel Ángel
 * @author 217218561 Huerta Villalobos José Genaro
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MainWindow mainWindow = new MainWindow();
        mainWindow.setVisible(true);
    }
}
