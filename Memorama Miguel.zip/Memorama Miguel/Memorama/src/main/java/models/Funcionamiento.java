/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import GUI.Gameplay;
import javax.swing.ImageIcon;
import javax.swing.JButton;

/**
 *
 * @author Owner
 */
public class Funcionamiento {
    
    
}
