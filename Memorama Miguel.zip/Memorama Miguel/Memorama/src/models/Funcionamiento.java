package models;

import java.util.Random;

/**
 *
 * @author Chico
 */
import java.util.Random;

public class Funcionamiento {

    private int comparaciones; // Variable para contar comparaciones

    public int[] desordenar() {
        comparaciones = 0; // Inicializar el contador de comparaciones
        int[] numeros = new int[16];
        int count = 0;

        while (count < 16) {
            Random rand = new Random();
            int numRand = rand.nextInt(8) + 1;
            int numRepetido = 0;

            for (int i = 0; i < 16; i++) {
                comparaciones++; // Incrementar el contador de comparaciones
                if (numeros[i] == numRand) {
                    numRepetido++;
                }
            }

            if (numRepetido < 2) {
                numeros[count] = numRand;
                count++;
            }
        }
        return numeros;
    }

    public int getComparaciones() {
        return comparaciones;
    }

    public static void main(String[] args) {
        Funcionamiento funcionamiento = new Funcionamiento();
        int[] numerosDesordenados = funcionamiento.desordenar();
        System.out.println("Numeros desordenados: " + java.util.Arrays.toString(numerosDesordenados));
        System.out.println("Número total de comparaciones: " + funcionamiento.getComparaciones());
    }
}
