package views;

import main.MainWindow;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Archivo en el que se hacen las pruebas unitarias
 * @author 220205792 Sanchez Alvarez Francisco Alberto / Chico
 * @author
 * @author
 * @author
 */
public class GameplayScreenTest {
    
    public GameplayScreenTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Prueba que se genere un arreglo de enteros de 8 pares con valores del 1-8 en desorden
     */
    @Test
    public void testDesordenar() {
        System.out.println("Desordenar 8 pares de cartas");
        MainWindow mainWindow = new MainWindow();
        GameplayScreen instance = new GameplayScreen(mainWindow);
        instance.tNumeros = instance.desordenar();
        
        int par1 = 1;
        int par2 = 2;
        int par3 = 3;
        int par4 = 4;
        int par5 = 5;
        int par6 = 6;
        int par7 = 7;
        int par8 = 8;
        
        int cantCartas = 0;
        int cartasEsperadas = 16;
        
        for (int i = 0; i < 16; i++) {
            if(par1 == instance.tNumeros[i]) cantCartas++;
            if(par2 == instance.tNumeros[i]) cantCartas++;
            if(par3 == instance.tNumeros[i]) cantCartas++;
            if(par4 == instance.tNumeros[i]) cantCartas++;
            if(par5 == instance.tNumeros[i]) cantCartas++;
            if(par6 == instance.tNumeros[i]) cantCartas++;
            if(par7 == instance.tNumeros[i]) cantCartas++;
            if(par8 == instance.tNumeros[i]) cantCartas++;
        }
        
        System.out.println("Cantidad de cartas esperadas: "+cartasEsperadas);
        System.out.println("Cantidad de cartas: "+cantCartas);
        System.out.print("Cartas desordenadas: ");
        
        for (int i = 0; i < 16; i++) {
            System.out.print(instance.tNumeros[i]+" ");
        }
        
        assertEquals(cartasEsperadas,cantCartas);
        
        System.out.println("");
        System.out.println("");
    }

    /**
     * Prueba que el boton se desactive para que despues se muestra la imagen de la carta
     */
    @Test
    public void testBotonEnable(){
        System.out.println("Test de seleccionar carta");
        MainWindow mainWindow = new MainWindow();
        GameplayScreen instance = new GameplayScreen(mainWindow);
        instance.tBotonEnable(instance.btn1);
        
        assertEquals(true,instance.tPrimerCarta);
        System.out.println("Se selecciono la carta");
        System.out.println("");
    }
  
    /**
     * Prueba que compare el contenido de 2 cartas seleccionadas
     */
    @Test
    public void testComparar(){
        System.out.println("Test de comparar");
        int[] num = {1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8};
        MainWindow mainWindow = new MainWindow();
        GameplayScreen instance = new GameplayScreen(mainWindow);
        instance.tNumeros = num;
        for (int i = 0; i < 16; i++) {
            System.out.print(instance.tNumeros[i]+" ");
        }

        instance.tSetCartas();
        
        instance.tBotonEnable(instance.btn1);
        instance.tBotonEnable(instance.btn2);
        
        instance.tComparar();
        
        int esperado = 20;
        
        assertEquals(esperado,instance.tPuntaje);
        
        System.out.println("");
        System.out.println("");

    }
    
    /**
     * Comprueba si la partida se ha terminado o sigue en progreso
     */
    @Test
    public void testGameSet(){
        System.out.println("Test de ganar");
        int[] num = {1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8};
        MainWindow mainWindow = new MainWindow();
        GameplayScreen instance = new GameplayScreen(mainWindow);
        instance.tNumeros = num;
        
        int esperado = 160;
        int esperadoIntentos = 8;
        boolean ganar = true;
        boolean enProgreso = false;
        
        System.out.print("Cartas: ");
        for (int i = 0; i < 16; i++) {
            System.out.print(instance.tNumeros[i]+" ");
        }
        
        instance.tSetCartas();
        
        instance.tBotonEnable(instance.btn1);
        instance.tBotonEnable(instance.btn2);
        instance.tComparar();
        
        instance.tBotonEnable(instance.btn3);
        instance.tBotonEnable(instance.btn4);
        instance.tComparar();
        
        instance.tBotonEnable(instance.btn5);
        instance.tBotonEnable(instance.btn6);
        instance.tComparar();
        
        instance.tBotonEnable(instance.btn7);
        instance.tBotonEnable(instance.btn8);
        instance.tComparar();
        
        instance.tBotonEnable(instance.btn9);
        instance.tBotonEnable(instance.btn10);
        instance.tComparar();
        
        instance.tBotonEnable(instance.btn11);
        instance.tBotonEnable(instance.btn12);
        instance.tComparar();
        
        assertEquals(enProgreso,instance.tGameSet());
        
        instance.tBotonEnable(instance.btn13);
        instance.tBotonEnable(instance.btn14);
        instance.tComparar();
        
        instance.tBotonEnable(instance.btn15);
        instance.tBotonEnable(instance.btn16);
        instance.tComparar();
        
        assertEquals(ganar,instance.tGameSet());
        assertEquals(esperado,instance.tPuntaje);
        assertEquals(esperadoIntentos,instance.tIntentos);
        
        System.out.println("");
        System.out.println("Puntaje total: "+ instance.tPuntaje);
        System.out.println("Puntaje total: "+ instance.tIntentos);
        System.out.println("");
    }
}
